#!/bin/sh

# path to mysql
export DB_HOME=/usr/bin/

# user name to access db
export USER_NAME=root

# password for above user
export USER_PASSWORD=password

# do not modify from below
export PATH=$PATH;$DB_HOME/bin;

echo create database
mysql -u $USER_NAME -p$USER_PASSWORD       < ./sql/mysql/00_create_sales_database.sql

echo create table
mysql -u $USER_NAME -p$USER_PASSWORD sales < ./sql/mysql/01_create_tables_for_sales_db.sql

echo insert data into item_class table
mysql -u $USER_NAME -p$USER_PASSWORD sales < ./sql/mysql/02_insert_item_class_table.sql

echo insert data into store_class table
mysql -u $USER_NAME -p$USER_PASSWORD sales < ./sql/mysql/03_insert_store_class.sql

echo insert data into prefecture table
mysql -u $USER_NAME -p$USER_PASSWORD sales < ./sql/mysql/04_insert_prefecture_table.sql

echo insert data into item table
mysql -u $USER_NAME -p$USER_PASSWORD sales < ./sql/mysql/05_insert_item_table.sql

echo insert data into customer table
mysql -u $USER_NAME -p$USER_PASSWORD sales < ./sql/mysql/06_insert_customer_table.sql

echo insert data into store table
mysql -u $USER_NAME -p$USER_PASSWORD sales < ./sql/mysql/07_insert_store_table.sql

echo insert data into sales table
mysql -u $USER_NAME -p$USER_PASSWORD sales < ./sql/mysql/08_insert_sales_table.sql
