DELETE FROM prefecture;
LOAD DATA LOCAL INFILE './data/prefecture.csv' INTO TABLE prefecture FIELDS TERMINATED BY ',';
