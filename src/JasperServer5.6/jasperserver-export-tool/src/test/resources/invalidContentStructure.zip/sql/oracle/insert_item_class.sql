load data
 characterset utf8
 into table item_class
 fields terminated by ","   	  
 ( item_class_name )

 