DELETE FROM item_class;
\set filepath '\'' :ROOT_DIR '/data/item_class.csv' '\''
COPY item_class (item_class_name) FROM :filepath WITH DELIMITER AS ',';
