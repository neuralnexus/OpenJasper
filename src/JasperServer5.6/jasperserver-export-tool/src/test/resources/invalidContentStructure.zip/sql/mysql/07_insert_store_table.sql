DELETE FROM store;
LOAD DATA LOCAL INFILE './data/store.csv' INTO TABLE store FIELDS TERMINATED BY ',' (store_name,square_measure,prefecture_id,store_class_id,opening_time,closing_time);
