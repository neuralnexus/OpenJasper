DELETE FROM prefecture;
\set filepath '\'' :ROOT_DIR '/data/prefecture.csv' '\''
COPY prefecture (prefecture_id, prefecture_name) FROM :filepath  WITH DELIMITER AS ',';

