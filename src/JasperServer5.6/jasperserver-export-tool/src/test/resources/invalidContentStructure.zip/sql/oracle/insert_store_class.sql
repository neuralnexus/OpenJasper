load data
 characterset utf8
 into table store_class
 fields terminated by ","   	  
 ( store_class_name )
