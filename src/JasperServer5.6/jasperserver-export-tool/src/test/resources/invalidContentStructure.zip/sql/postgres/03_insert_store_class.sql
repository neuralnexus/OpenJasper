DELETE FROM store_class;
\set filepath '\'' :ROOT_DIR '/data/store_class.csv' '\''
COPY store_class (store_class_name) FROM :filepath  WITH DELIMITER AS ',';
