DELETE FROM customer;

LOAD DATA LOCAL INFILE './data/customer.csv' INTO TABLE customer FIELDS TERMINATED BY ',' (full_name,gender,birth_date,prefecture_id,married);

