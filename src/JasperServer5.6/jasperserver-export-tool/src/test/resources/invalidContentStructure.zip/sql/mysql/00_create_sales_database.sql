drop database if exists sales;
create database sales;
use sales;
set character_set_database   = utf8;
set character_set_server     = utf8;
set character_set_client     = utf8;
set character_set_connection = utf8;
set character_set_results    = utf8;