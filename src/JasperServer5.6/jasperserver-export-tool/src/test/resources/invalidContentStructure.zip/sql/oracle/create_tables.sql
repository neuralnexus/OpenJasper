connect &1/&2@&3;

/* Drop Tables, Sequences, Triggers */
drop table sales;
drop sequence sales_seq;

drop table store;
drop sequence store_seq;

drop table customer;
drop sequence customer_seq;

drop table item;
drop sequence item_seq;

drop table prefecture;

drop table store_class;
drop sequence store_class_seq;

drop table item_class;
drop sequence item_class_seq;

/* define item_class */

CREATE TABLE item_class (
    item_class_id int NOT NULL,
    item_class_name varchar(50) NOT NULL,
    PRIMARY KEY (item_class_id)
);

create sequence item_class_seq 
  start with 1 
  increment by 1 
  nomaxvalue; 

create trigger item_class_trigger
  before insert on item_class
  for each row
  begin
    select item_class_seq.nextval into :new.item_class_id from dual;
  end;
/

/* define store_class */

CREATE TABLE store_class (
	store_class_id int NOT NULL,
	store_class_name varchar(50) NOT NULL,
	PRIMARY KEY (store_class_id)
);

create sequence store_class_seq 
  start with 1 
  increment by 1 
  nomaxvalue; 

create trigger store_class_trigger
  before insert on store_class
  for each row
  begin
    select store_class_seq.nextval into :new.store_class_id from dual;
  end;
/

/* degine prefecture */

create table prefecture
(
	prefecture_id char(2) NOT NULL,
	prefecture_name char(50) NOT NULL,
	PRIMARY KEY (prefecture_id)
);

/* degine item */

create table item
(
	item_id int NOT NULL,
	item_name varchar(50) NOT NULL,
	price int NOT NULL,
	item_class_id int NOT NULL,
	PRIMARY KEY (item_id),
	CONSTRAINT fk_item_class_id
	    FOREIGN KEY (item_class_id)
            REFERENCES item_class(item_class_id)
);

create sequence item_seq 
  start with 1 
  increment by 1 
  nomaxvalue; 

create trigger item_trigger
  before insert on item
  for each row
  begin
    select store_class_seq.nextval into :new.item_id from dual;
  end;
/

/* degine customer */

CREATE TABLE customer
(
	customer_id int NOT NULL,
	full_name varchar(50) NOT NULL,
	gender char(3) NOT NULL,
	birth_date date NOT NULL,
	prefecture_id char(2) NOT NULL,
	married char(10) NOT NULL,
	PRIMARY KEY (customer_id),
	CONSTRAINT fk_prefecture_id
	    FOREIGN KEY (prefecture_id)
            REFERENCES prefecture(prefecture_id)
);

create sequence customer_seq 
  start with 1 
  increment by 1 
  nomaxvalue; 

create trigger customer_trigger
  before insert on customer
  for each row
  begin
    select customer_seq.nextval into :new.customer_id from dual;
  end;
/

/* define store */

CREATE TABLE store
(
	store_id int NOT NULL,
	store_name varchar(50) NOT NULL,
	square_measure int NOT NULL,
	prefecture_id char(2) NOT NULL,
	store_class_id int NOT NULL,
	opening_time date NOT NULL,
	closing_time date NOT NULL,
	PRIMARY KEY (store_id),
	CONSTRAINT fk_store_prefecture_id
	    FOREIGN KEY (prefecture_id)
            REFERENCES prefecture(prefecture_id),
	CONSTRAINT fk_store_store_class_id
	    FOREIGN KEY (store_class_id)
            REFERENCES store_class(store_class_id)	
);

create sequence store_seq 
  start with 1 
  increment by 1 
  nomaxvalue; 

create trigger store_trigger
  before insert on store
  for each row
  begin
    select store_seq.nextval into :new.store_id from dual;
  end;
/

/* define sales */

CREATE TABLE sales
(
	sales_id int NOT NULL,
	purchased_time timestamp NOT NULL,
	sales_amount int NOT NULL,
	customer_id int NOT NULL,
	store_id int NOT NULL,
	item_id int NOT NULL,
	PRIMARY KEY (sales_id),
	CONSTRAINT fk_sales_store_id
	    FOREIGN KEY (store_id)
            REFERENCES store(store_id),
	CONSTRAINT fk_sales_item_id
	    FOREIGN KEY (item_id)
            REFERENCES item(item_id)
);

create sequence sales_seq
  start with 1 
  increment by 1 
  nomaxvalue; 

create trigger sales_trigger
  before insert on sales
  for each row
  begin
    select sales_seq.nextval into :new.sales_id from dual;
  end;
/

exit;
