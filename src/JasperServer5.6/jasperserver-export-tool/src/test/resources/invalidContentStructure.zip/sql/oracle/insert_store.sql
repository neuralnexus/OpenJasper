load data
 characterset utf8
 into table store
 fields terminated by ","   	  
 ( store_name,
   square_measure,
   prefecture_id,
   store_class_id,
   opening_time "TO_DATE( :opening_time,'HH24:MI')",
   closing_time "TO_DATE( :closing_time,'HH24:MI')"
 )
