load data
 characterset utf8
 into table customer
 fields terminated by ","   	  
 ( full_name,
   gender,
   birth_date "TO_DATE( :birth_date,'yyyy/mm/dd')",
   prefecture_id,
   married )