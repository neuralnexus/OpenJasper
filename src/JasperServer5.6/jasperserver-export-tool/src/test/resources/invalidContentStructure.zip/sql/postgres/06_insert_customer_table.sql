DELETE FROM customer;
\set filepath '\'' :ROOT_DIR '/data/customer.csv' '\''
COPY customer (full_name,gender,birth_date,prefecture_id, married) FROM :filepath  WITH DELIMITER AS ',';
