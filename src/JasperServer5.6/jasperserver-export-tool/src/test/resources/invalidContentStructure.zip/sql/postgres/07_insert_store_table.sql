DELETE FROM store;
\set filepath '\'' :ROOT_DIR '/data/store.csv' '\''
COPY store (store_name, square_measure, prefecture_id, store_class_id,opening_time,closing_time) FROM :filepath  WITH DELIMITER AS ',';
