DELETE from sales;
LOAD DATA LOCAL INFILE './data/sales.csv' INTO TABLE sales FIELDS TERMINATED BY ',' (purchased_time,sales_amount,customer_id,store_id,item_id);
