
/* Drop Tables */

DROP TABLE IF EXISTS sales;
DROP TABLE IF EXISTS customer;
DROP TABLE IF EXISTS store;
DROP TABLE IF EXISTS prefecture;
DROP TABLE IF EXISTS store_class;
DROP TABLE IF EXISTS item;
DROP TABLE IF EXISTS item_class;

/* Create Tables */

CREATE TABLE customer
(
	customer_id int NOT NULL AUTO_INCREMENT,
	full_name varchar(50) NOT NULL,
	gender char(1) NOT NULL,
	birth_date date NOT NULL,
	prefecture_id int NOT NULL,
	married boolean NOT NULL,
	PRIMARY KEY (customer_id)
);


CREATE TABLE prefecture
(
	prefecture_id int NOT NULL,
	prefecture_name char(50) NOT NULL,
	PRIMARY KEY (prefecture_id)
);


CREATE TABLE sales
(
	sales_id int NOT NULL AUTO_INCREMENT,
	purchased_time timestamp NOT NULL,
	sales_amount int NOT NULL,
	customer_id int NOT NULL,
	store_id int NOT NULL,
	item_id int NOT NULL,
	PRIMARY KEY (sales_id)
);


CREATE TABLE store
(
	store_id int NOT NULL AUTO_INCREMENT,
	store_name varchar(50) NOT NULL,
	square_measure int NOT NULL,
	prefecture_id int NOT NULL,
	store_class_id int NOT NULL,
	opening_time time NOT NULL,
	closing_time time NOT NULL,
	PRIMARY KEY (store_id)
);


CREATE TABLE store_class
(
	store_class_id int NOT NULL AUTO_INCREMENT,
	store_class_name varchar(50) NOT NULL,
	PRIMARY KEY (store_class_id)
);


CREATE TABLE item
(
	item_id int NOT NULL AUTO_INCREMENT,
	item_name varchar(50) NOT NULL,
	price int NOT NULL,
	item_class_id int NOT NULL,
	PRIMARY KEY (item_id)
);


CREATE TABLE item_class
(
	item_class_id int NOT NULL AUTO_INCREMENT,
	item_class_name varchar(50) NOT NULL,
	PRIMARY KEY (item_class_id)
);


/* Create Foreign Keys */

ALTER TABLE sales
	ADD FOREIGN KEY (customer_id)
	REFERENCES customer (customer_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE customer
	ADD FOREIGN KEY (prefecture_id)
	REFERENCES prefecture (prefecture_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE store
	ADD FOREIGN KEY (prefecture_id)
	REFERENCES prefecture (prefecture_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE sales
	ADD FOREIGN KEY (store_id)
	REFERENCES store (store_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE store
	ADD FOREIGN KEY (store_class_id)
	REFERENCES store_class (store_class_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE sales
	ADD FOREIGN KEY (item_id)
	REFERENCES item (item_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;


ALTER TABLE item
	ADD FOREIGN KEY (item_class_id)
	REFERENCES item_class (item_class_id)
	ON UPDATE RESTRICT
	ON DELETE RESTRICT
;
