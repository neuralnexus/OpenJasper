DELETE FROM item;
LOAD DATA LOCAL INFILE './data/item.csv' INTO TABLE item FIELDS TERMINATED BY ',' (item_name,price,item_class_id);
