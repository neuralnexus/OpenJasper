DELETE FROM store_class;
LOAD DATA LOCAL INFILE './data/store_class.csv' INTO TABLE store_class (store_class_name);
