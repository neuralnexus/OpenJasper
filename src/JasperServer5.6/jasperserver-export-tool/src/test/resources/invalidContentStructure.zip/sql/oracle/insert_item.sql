load data
 characterset utf8
 into table item
 fields terminated by ","   	  
 ( item_name, price, item_class_id )