load data
 characterset utf8
 into table prefecture
 fields terminated by ","   	  
 ( prefecture_id, prefecture_name )