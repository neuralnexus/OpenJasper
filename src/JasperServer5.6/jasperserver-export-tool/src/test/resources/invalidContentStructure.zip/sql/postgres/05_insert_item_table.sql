DELETE FROM item;
\set filepath '\'' :ROOT_DIR '/data/item.csv' '\''
COPY item (item_name, price, item_class_id) FROM :filepath  WITH DELIMITER AS ',';
