drop database if exists sales;
create database sales;
