DELETE FROM item_class;
LOAD DATA LOCAL INFILE './data/item_class.csv' INTO TABLE item_class (item_class_name);
