load data
 characterset utf8
 into table sales
 fields terminated by ","   	  
 ( purchased_time "TO_TIMESTAMP( :purchased_time,'yyyy/mm/dd hh24:mi:ss')",
   sales_amount,
   customer_id,
   store_id,
   item_id
 )
