DELETE FROM sales;
\set filepath '\'' :ROOT_DIR '/data/sales.csv' '\''
COPY sales (purchased_time, sales_amount, customer_id, store_id, item_id) FROM :filepath  WITH DELIMITER AS ',';
