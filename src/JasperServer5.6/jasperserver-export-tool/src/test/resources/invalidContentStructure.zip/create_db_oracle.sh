# directory that this file located
export SCRIPT_HOME=/root/create_sales_db

# home directory for PostgreSQL
export ORACLE_HOME=/u01/app/oracle/product/11.2.0/dbhome_1/

# user name to access db
export USER_NAME=system

# password for above user
export USER_PASSWORD=just4eng

# database name you access
export DB_NAME=yohei

# do not modify from below
export PATH=$PATH:$ORACLE_HOME/bin;
export MY_USER_NAME=salesuser
export MY_PASSWORD=salespass

sqlplus $USER_NAME/$USER_PASSWORD@$DB_NAME @./sql/oracle/create_user.sql   $MY_USER_NAME $MY_PASSWORD
sqlplus $USER_NAME/$USER_PASSWORD@$DB_NAME @./sql/oracle/create_tables.sql $MY_USER_NAME $MY_PASSWORD $DB_NAME

sqlldr $MY_USER_NAME/$MY_PASSWORD@$DB_NAME control=./sql/oracle/insert_item_class.sql  data=./data/item_class.csv
sqlldr $MY_USER_NAME/$MY_PASSWORD@$DB_NAME control=./sql/oracle/insert_store_class.sql data=./data/store_class.csv
sqlldr $MY_USER_NAME/$MY_PASSWORD@$DB_NAME control=./sql/oracle/insert_prefecture.sql  data=./data/prefecture.csv
sqlldr $MY_USER_NAME/$MY_PASSWORD@$DB_NAME control=./sql/oracle/insert_item.sql        data=./data/item.csv
sqlldr $MY_USER_NAME/$MY_PASSWORD@$DB_NAME control=./sql/oracle/insert_customer.sql    data=./data/customer.csv
sqlldr $MY_USER_NAME/$MY_PASSWORD@$DB_NAME control=./sql/oracle/insert_store.sql       data=./data/store.csv
sqlldr $MY_USER_NAME/$MY_PASSWORD@$DB_NAME control=./sql/oracle/insert_sales.sql       data=./data/sales.csv rows=-1
