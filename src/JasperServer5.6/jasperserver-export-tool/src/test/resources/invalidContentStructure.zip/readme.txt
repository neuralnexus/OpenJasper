Written by Yohei Onishi, 02/12/2014
yonishi@jaspersoft.com

This is a sample Japanese database for localization testing.
It contains typical sales data of a retail shop such as food, drink, book, home electronics, etc.
 e.g.) A Customer "Taro Yamada" who lives in Tokyo bought two books at the bookstore located in Tokyo on Jan 24 2014.
Character data are written in Japanese. Column names are written in English.
e.g.) customer name, store name, item name, item classification, etc are written in Japanese. 

See below wiki page for detail.
http://wiki.jaspersoft.com:8080/display/sandbox/Sample+Japanese+database+for+localization+testing

