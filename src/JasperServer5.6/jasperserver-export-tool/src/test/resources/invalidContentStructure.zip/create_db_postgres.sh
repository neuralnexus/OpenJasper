#!/bin/sh

# directory of PostgreSQL
export PSQL_HOME=/home/engineer/jrs5.6p/postgresql

# the directory that this file is located
export ROOT_DIR=/home/engineer/create_sales_db

# user name to access db
export USER_NAME=postgres

# password for above user
export PGPASSWORD=postgres

# do not modify under below
export PGCLIENTENCODING=UTF-8;
export PATH=$PATH:$PSQL_HOME/bin;

psql -U $USER_NAME                                 < ./sql/postgres/00_create_sales_database.sql
psql -U $USER_NAME -e sales                        < ./sql/postgres/01_create_tables_for_sales_db.sql
psql -U $USER_NAME -v ROOT_DIR=$ROOT_DIR -e sales < ./sql/postgres/02_insert_item_class_table.sql
psql -U $USER_NAME -v ROOT_DIR=$ROOT_DIR -e sales < ./sql/postgres/03_insert_store_class.sql
psql -U $USER_NAME -v ROOT_DIR=$ROOT_DIR -e sales < ./sql/postgres/04_insert_prefecture_table.sql
psql -U $USER_NAME -v ROOT_DIR=$ROOT_DIR -e sales < ./sql/postgres/05_insert_item_table.sql
psql -U $USER_NAME -v ROOT_DIR=$ROOT_DIR -e sales < ./sql/postgres/06_insert_customer_table.sql
psql -U $USER_NAME -v ROOT_DIR=$ROOT_DIR -e sales < ./sql/postgres/07_insert_store_table.sql
psql -U $USER_NAME -v ROOT_DIR=$ROOT_DIR -e sales < ./sql/postgres/08_insert_sales_table.sql
